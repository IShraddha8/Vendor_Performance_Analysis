"""
generate_data.py
-----------------
Creates a SMALL synthetic dataset that mimics a real vendor/sales dataset,
so the rest of the project can run end-to-end without needing real
company data or a SQL Server install.

Creates 4 CSVs inside data/:
    purchases.csv
    purchase_prices.csv
    vendor_invoice.csv
    sales.csv
"""

import numpy as np
import pandas as pd
import os

np.random.seed(42)
os.makedirs("data", exist_ok=True)

# ---- basic building blocks: 15 vendors, 30 brands ----
vendor_names = [
    "Diageo North America", "Pernod Ricard USA", "Bacardi USA",
    "Constellation Brands", "Brown-Forman", "Jim Beam Brands",
    "E & J Gallo Winery", "Martignetti Companies", "M S Walker",
    "Ultra Beverage Company", "Truett Hurst", "Ira Goldman & Williams",
    "Vineyard Brands", "Loyal Dog Winery", "Uncorked",
]
vendors = pd.DataFrame({
    "VendorNumber": range(1, len(vendor_names) + 1),
    "VendorName": vendor_names,
})

brand_names = [f"Brand_{i}" for i in range(1, 31)]
# each brand belongs to one vendor (simplified 1-to-many)
brand_vendor_map = np.random.choice(vendors["VendorNumber"], size=len(brand_names))
brands = pd.DataFrame({
    "Brand": range(101, 101 + len(brand_names)),
    "Description": brand_names,
    "VendorNumber": brand_vendor_map,
})
brands = brands.merge(vendors, on="VendorNumber")

# ---- purchase_prices: one row per vendor+brand ----
purchase_prices = brands.copy()
purchase_prices["PurchasePrice"] = np.round(np.random.uniform(3, 60, size=len(brands)), 2)
purchase_prices["Volume"] = np.random.choice([50, 175, 375, 750, 1000], size=len(brands))
purchase_prices["Price"] = np.round(purchase_prices["PurchasePrice"] * np.random.uniform(1.3, 1.8, size=len(brands)), 2)
purchase_prices = purchase_prices[["VendorNumber", "VendorName", "Brand", "Description", "PurchasePrice", "Volume", "Price"]]
purchase_prices.to_csv("data/purchase_prices.csv", index=False)

# ---- purchases: many transactions per vendor+brand ----
rows = []
for _, r in brands.iterrows():
    n_tx = np.random.randint(5, 15)
    base_price = purchase_prices.loc[purchase_prices.Brand == r.Brand, "PurchasePrice"].values[0]
    for _ in range(n_tx):
        qty = np.random.randint(5, 500)
        rows.append({
            "VendorNumber": r.VendorNumber,
            "VendorName": r.VendorName,
            "Brand": r.Brand,
            "Description": r.Description,
            "PurchasePrice": base_price,
            "Quantity": qty,
            "Dollars": round(qty * base_price, 2),
        })
purchases = pd.DataFrame(rows)
purchases.to_csv("data/purchases.csv", index=False)

# ---- vendor_invoice: freight per PO ----
invoice_rows = []
po_num = 1000
for vn in vendors["VendorNumber"]:
    n_po = np.random.randint(3, 8)
    for _ in range(n_po):
        invoice_rows.append({
            "VendorNumber": vn,
            "PONumber": po_num,
            "Freight": round(np.random.uniform(50, 2000), 2),
        })
        po_num += 1
vendor_invoice = pd.DataFrame(invoice_rows)
vendor_invoice.to_csv("data/vendor_invoice.csv", index=False)

# ---- sales: many transactions per vendor+brand ----
sales_rows = []
for _, r in brands.iterrows():
    n_tx = np.random.randint(5, 20)
    actual_price = purchase_prices.loc[purchase_prices.Brand == r.Brand, "Price"].values[0]
    for _ in range(n_tx):
        qty = np.random.randint(1, 300)
        sales_rows.append({
            "VendorNo": r.VendorNumber,
            "Brand": r.Brand,
            "SalesQuantity": qty,
            "SalesPrice": actual_price,
            "SalesDollars": round(qty * actual_price, 2),
            "ExciseTax": round(qty * actual_price * 0.05, 2),
        })
sales = pd.DataFrame(sales_rows)
sales.to_csv("data/sales.csv", index=False)

print("Sample data generated in data/:")
print(f"  purchases.csv       -> {len(purchases)} rows")
print(f"  purchase_prices.csv -> {len(purchase_prices)} rows")
print(f"  vendor_invoice.csv  -> {len(vendor_invoice)} rows")
print(f"  sales.csv            -> {len(sales)} rows")
