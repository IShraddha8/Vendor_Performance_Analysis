"""
eda_summary.py
---------------
Step 1: Explore the raw tables (row counts, sample rows).
Step 2: Build ONE summary table (vendor_sales_summary) by joining and
        aggregating purchases + purchase_prices + vendor_invoice + sales.
Step 3: Clean it and add 4 business metrics.
Step 4: Save it back to the database for the dashboard / analysis stage.
"""

import pandas as pd
import numpy as np
from sqlalchemy import create_engine, text

engine = create_engine("sqlite:///inventory.db")
conn = engine.connect()

# -------------------------------------------------
# STEP 1: Look at what we're working with
# -------------------------------------------------
tables = pd.read_sql(
    "SELECT name AS TABLE_NAME FROM sqlite_master WHERE type='table'", conn
)
print("Tables in database:\n", tables, "\n")

for table in tables["TABLE_NAME"]:
    count = pd.read_sql(f"SELECT COUNT(*) AS count FROM {table}", conn)["count"][0]
    print(f"{table} -> {count} rows")

# -------------------------------------------------
# STEP 2: Build the summary table with one SQL query
# -------------------------------------------------
query = """
WITH FreightSummary AS (
    SELECT VendorNumber, SUM(Freight) AS FreightCost
    FROM vendor_invoice
    GROUP BY VendorNumber
),

PurchaseSummary AS (
    SELECT
        p.VendorNumber, p.VendorName, p.Brand, p.Description,
        p.PurchasePrice, pp.Volume, pp.Price AS ActualPrice,
        SUM(p.Quantity) AS TotalPurchaseQuantity,
        SUM(p.Dollars)  AS TotalPurchaseDollars
    FROM purchases p
    JOIN purchase_prices pp ON p.Brand = pp.Brand
    WHERE p.PurchasePrice > 0
    GROUP BY p.VendorNumber, p.VendorName, p.Brand, p.Description,
             p.PurchasePrice, pp.Volume, pp.Price
),

SalesSummary AS (
    SELECT
        VendorNo, Brand,
        SUM(SalesDollars)  AS TotalSalesDollars,
        SUM(SalesPrice)    AS TotalSalesPrice,
        SUM(SalesQuantity) AS TotalSalesQuantity,
        SUM(ExciseTax)     AS TotalExciseTax
    FROM sales
    GROUP BY VendorNo, Brand
)

SELECT
    ps.VendorNumber, ps.VendorName, ps.Brand, ps.Description,
    ps.PurchasePrice, ps.ActualPrice, ps.Volume,
    ps.TotalPurchaseQuantity, ps.TotalPurchaseDollars,
    ss.TotalSalesQuantity, ss.TotalSalesDollars,
    ss.TotalSalesPrice, ss.TotalExciseTax,
    fs.FreightCost
FROM PurchaseSummary ps
LEFT JOIN SalesSummary ss ON ps.VendorNumber = ss.VendorNo AND ps.Brand = ss.Brand
LEFT JOIN FreightSummary fs ON ps.VendorNumber = fs.VendorNumber
"""

vendor_sales_summary = pd.read_sql(query, conn)

# -------------------------------------------------
# STEP 3: Clean
# -------------------------------------------------
vendor_sales_summary["VendorName"] = vendor_sales_summary["VendorName"].str.strip()
vendor_sales_summary["Description"] = vendor_sales_summary["Description"].str.strip()
vendor_sales_summary.fillna(0, inplace=True)
vendor_sales_summary["Volume"] = vendor_sales_summary["Volume"].astype(float)

# -------------------------------------------------
# STEP 4: Add business metrics
# -------------------------------------------------
vendor_sales_summary["GrossProfit"] = (
    vendor_sales_summary["TotalSalesDollars"]
    - (vendor_sales_summary["TotalSalesQuantity"] * vendor_sales_summary["PurchasePrice"])
)

vendor_sales_summary["ProfitMargin"] = np.where(
    vendor_sales_summary["TotalSalesDollars"] > 0,
    (vendor_sales_summary["GrossProfit"] / vendor_sales_summary["TotalSalesDollars"]) * 100,
    0,
)

vendor_sales_summary["StockTurnover"] = (
    vendor_sales_summary["TotalSalesQuantity"] / vendor_sales_summary["TotalPurchaseQuantity"]
)

vendor_sales_summary["SalesToPurchaseRatio"] = (
    vendor_sales_summary["TotalSalesDollars"] / vendor_sales_summary["TotalPurchaseDollars"]
)

# -------------------------------------------------
# STEP 5: Save back to the database
# -------------------------------------------------
with engine.begin() as write_conn:
    vendor_sales_summary.to_sql(
        "vendor_sales_summary", con=write_conn, if_exists="replace", index=False
    )

print(f"\nvendor_sales_summary created -> {vendor_sales_summary.shape[0]} rows")
print(vendor_sales_summary.head())
