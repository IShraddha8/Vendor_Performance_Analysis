"""
analysis.py
------------
Reads vendor_sales_summary and answers the business questions with a
few simple charts + one hypothesis test. Saves charts into charts/.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from sqlalchemy import create_engine
import os

os.makedirs("charts", exist_ok=True)
engine = create_engine("sqlite:///inventory.db")
df = pd.read_sql("SELECT * FROM vendor_sales_summary", engine)

print("Rows:", len(df))
print(df.describe().round(2))

# -------------------------------------------------
# 1) Top vendors by sales
# -------------------------------------------------
top_vendors = (
    df.groupby("VendorName")["TotalSalesDollars"].sum()
    .sort_values(ascending=False).head(10)
)
plt.figure(figsize=(8, 5))
top_vendors.plot(kind="barh", color="steelblue")
plt.gca().invert_yaxis()
plt.title("Top Vendors by Total Sales")
plt.xlabel("Total Sales ($)")
plt.tight_layout()
plt.savefig("charts/top_vendors.png")
plt.close()

# -------------------------------------------------
# 2) Vendor concentration (Pareto / 80-20 check)
# -------------------------------------------------
purchase_by_vendor = (
    df.groupby("VendorName")["TotalPurchaseDollars"].sum().sort_values(ascending=False)
)
share = (purchase_by_vendor / purchase_by_vendor.sum() * 100).round(2)
top10_share = share.head(10).sum()
print(f"\nTop 10 vendors account for {top10_share:.1f}% of total purchase value")

plt.figure(figsize=(8, 5))
cum_share = share.cumsum()
plt.bar(range(len(share)), share.values, color="darkslateblue")
plt.plot(range(len(share)), cum_share.values, color="red", marker="o")
plt.title("Vendor Contribution to Total Purchases (Pareto view)")
plt.ylabel("Share (%)")
plt.tight_layout()
plt.savefig("charts/pareto_vendors.png")
plt.close()

# -------------------------------------------------
# 3) Profit margin distribution
# -------------------------------------------------
plt.figure(figsize=(7, 5))
df["ProfitMargin"].hist(bins=15, color="seagreen", edgecolor="black")
plt.title("Distribution of Profit Margin (%)")
plt.xlabel("Profit Margin (%)")
plt.tight_layout()
plt.savefig("charts/profit_margin_hist.png")
plt.close()

# -------------------------------------------------
# 4) Do bigger vendors (by sales) really have lower margins?
#    Simple hypothesis test: top 25% vs bottom 25% by TotalSalesDollars
# -------------------------------------------------
sorted_df = df.sort_values("TotalSalesDollars")
n = len(sorted_df)
low_group = sorted_df.iloc[: n // 4]["ProfitMargin"]
top_group = sorted_df.iloc[-(n // 4):]["ProfitMargin"]

t_stat, p_value = stats.ttest_ind(top_group, low_group, equal_var=False)

print(f"\nTop-sales vendors avg margin:  {top_group.mean():.2f}%")
print(f"Low-sales vendors avg margin:  {low_group.mean():.2f}%")
print(f"T-test: t={t_stat:.3f}, p={p_value:.4f}")
if p_value < 0.05:
    print("-> Statistically significant difference between the two groups.")
else:
    print("-> No statistically significant difference (expected on small sample data).")

# -------------------------------------------------
# 5) Vendors with the lowest stock turnover (slow-moving stock)
# -------------------------------------------------
low_turnover = df.sort_values("StockTurnover").head(5)[
    ["VendorName", "Description", "StockTurnover"]
]
print("\nLowest stock-turnover vendors (capital tied up):")
print(low_turnover.to_string(index=False))

print("\nCharts saved in charts/: top_vendors.png, pareto_vendors.png, profit_margin_hist.png")
