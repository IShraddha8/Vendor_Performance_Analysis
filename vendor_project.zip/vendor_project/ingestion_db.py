"""
ingestion_db.py
----------------
Loads every CSV inside data/ into a SQLite database (inventory.db).

Note: the original company project used SQL Server. This version uses
SQLite instead so the whole project runs on any laptop with just Python -
no database server install needed. The logic (read CSV -> push to a table)
is identical either way.
"""

import pandas as pd
import os
import time
import logging
from sqlalchemy import create_engine

os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    filename="logs/ingestion_db.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="a",
)


def create_db_engine():
    """SQLite engine -> creates inventory.db in the current folder."""
    return create_engine("sqlite:///inventory.db")


def ingest_db(df, table_name, engine):
    """Push one DataFrame into the database as a table."""
    df.to_sql(table_name, con=engine, if_exists="replace", index=False)


def load_raw_data(engine):
    """Read every CSV in data/ and load it into the database."""
    start = time.time()
    for file in os.listdir("data"):
        if file.endswith(".csv"):
            df = pd.read_csv(os.path.join("data", file))
            table_name = file[:-4]
            logging.info(f"Ingesting {file} into table '{table_name}'")
            ingest_db(df, table_name, engine)
            print(f"Loaded {file} -> table '{table_name}' ({len(df)} rows)")
    minutes = (time.time() - start) / 60
    logging.info("-------------Ingestion Complete-------------")
    logging.info(f"Total Time Taken: {minutes:.4f} minutes")


if __name__ == "__main__":
    engine = create_db_engine()
    load_raw_data(engine)
    print("\nAll CSVs loaded into inventory.db")
