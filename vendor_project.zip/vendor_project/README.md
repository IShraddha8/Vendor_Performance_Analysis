# Vendor Performance Analysis (Simplified Rebuild)

A small, self-contained analytics project that looks at vendor and brand
level purchase & sales data to see which vendors are profitable and which
ones are tying up cash in slow-moving stock.

This is a simplified, runnable rebuild of a larger company project. It uses
**SQLite** instead of SQL Server so it runs anywhere with just Python — no
database install needed — and a **small synthetic dataset** (~300-400 rows)
instead of millions of real records, so it's easy to read and explain.

## How it works (run in this order)

```
1. python generate_data.py   -> creates small sample CSVs in data/
2. python ingestion_db.py    -> loads those CSVs into inventory.db
3. python eda_summary.py     -> explores tables, builds vendor_sales_summary
4. python analysis.py        -> stats + charts (saved in charts/)
```

## Files

| File | Purpose |
|---|---|
| `generate_data.py` | Creates fake but realistic purchases/sales/prices/invoice data |
| `ingestion_db.py` | Loads CSVs from `data/` into a SQLite database |
| `eda_summary.py` | Joins & aggregates raw tables into one summary table, cleans it, adds metrics |
| `analysis.py` | Reads the summary table, produces charts + a simple hypothesis test |

## The 4 raw tables
- **purchases** — every purchase transaction (vendor, brand, qty, $)
- **purchase_prices** — agreed price per vendor+brand
- **vendor_invoice** — freight cost per purchase order
- **sales** — every sale transaction (vendor, brand, qty, $, tax)

## The 4 calculated metrics
- **GrossProfit** = TotalSalesDollars − (TotalSalesQuantity × PurchasePrice)
- **ProfitMargin** = GrossProfit / TotalSalesDollars × 100
- **StockTurnover** = TotalSalesQuantity / TotalPurchaseQuantity (low = slow-moving stock)
- **SalesToPurchaseRatio** = TotalSalesDollars / TotalPurchaseDollars

## What the analysis answers
- Which vendors bring in the most revenue?
- How concentrated is our vendor base (do a few vendors dominate)?
- Do smaller vendors have better profit margins than big ones?
- Which vendors have slow-moving stock (capital stuck on the shelf)?

## Notes on the numbers
Because the dataset is small and randomly generated, results (like the
hypothesis test) may not always be statistically significant — that's
expected and fine to say out loud. The point of this rebuild is to show the
*pipeline and the logic* clearly, not to reproduce the exact business
numbers from the original 1.8GB dataset.

## Possible next steps
- Swap SQLite for SQL Server / Postgres for a real deployment
- Add data validation checks after ingestion
- Connect Power BI (or any BI tool) directly to `inventory.db` / `vendor_sales_summary`
- Schedule the pipeline to refresh automatically
